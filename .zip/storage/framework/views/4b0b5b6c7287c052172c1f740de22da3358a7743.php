<?php $__env->startSection('content'); ?>

            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                    <div class="row">
                        <div class="col-12 d-flex no-block align-items-center">
                            <h4 class="page-title">Manage Billings</h4>

                            <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Billings</li>
                                    </ol>
                                </nav>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Container fluid  -->
                <!-- ============================================================== -->
                <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <?php if(session('successb')): ?>
                <div class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Success! </strong><?php echo e(session('successb')); ?>

                </div>
                <?php endif; ?>
                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Error!</strong>
                    <?php echo e($errors->first('ornumber')); ?><br>
                    <?php echo e($errors->first('paymentdate')); ?><br>
                    <?php echo e($errors->first('amount')); ?><br>
                </div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"></h5>
                        <div class="table-responsive">
                        <table class="table table-sm table-hover table-striped">
                    <thead>
                      <tr>
                        <th scope="col">JO#</th>
                        <th scope="col">Company/Client Name</th>
                        <th scope="col">Date Created</th>
                        <th scope="col">Amount Due</th>
                        <th scope="col">Amount Paid</th>
                        <th scope="col">OR Number</th>
                        <th scope="col">Balance</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if(count($billings) > 0): ?>
                         <?php $__currentLoopData = $billings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr id="tr">
                           <td><?php echo e($bill->id); ?></td>
                           <td><?php echo e($bill->clientname); ?></td>
                           <td align="right"><?php echo e($bill->created_at); ?></td>
                           <td align="right"><?php echo e(number_format($bill->amount, 2, '.', ',')); ?></td>
                           <td align="right"><?php echo e(number_format($bill->paidamount, 2, '.', ',')); ?></td>
                           <td><?php echo e($bill->ornumber); ?></td>
                           <td align="right">Php <?php echo e(number_format(($bill->amount - $bill->paidamount), 2, '.', ',')); ?>

                           </td>
                           <td align="center">
                           <?php if(($bill->amount - $bill->paidamount) == 0): ?>

                           <?php else: ?>
                           <button class="btn btn-success" onClick="addpayment('<?php echo e($bill->id); ?>','<?php echo e(($bill->amount - $bill->paidamount)); ?>')" data-toggle="modal" data-target="#paymentModal" rel="tooltip" title="Add Payment" type="button"><span class="fa fa-credit-card"></span></button>
                           <?php endif; ?>
                           <a href="<?php echo e(url('billing/jid')); ?>/<?php echo e($bill->id); ?>" target="_blank">
                           <button class="btn btn-info" onClick="" data-toggle="modal" data-target="" rel="tooltip" title="View Transaction" type="button"><span class="fa fa-print"></span></button>
                           </a>
                          </td>
                          </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php else: ?>
                         <tr>
                           <td colspan="7">NO Client's Billing Found.</td>
                         </tr>
                         <?php endif; ?>
                    </tbody>
                  </table>
                  <?php echo e($billings->links()); ?>


                        </div>
                    </div>
                </div>

                

<!-- Modal -->
<div class="modal fade" id="paymentModal" tabindex="" role="dialog" aria-labelledby="paymentModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Payment to JO</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form class="form-horizontal" id="paymentForm" action="<?php echo e(url('/billing/addpayment')); ?>" method="post">
          <?php echo e(csrf_field()); ?>

          <input type="text" name="joid" id="joid" value="" hidden>
          <div class="form-group col-sm-12">


            <div class="input-group input-group-sm mb-3">
              <div class="input-group-prepend">
                <span class="input-group-text" id="inputGroup-sizing-sm">OR Number:&nbsp &nbsp</span>
              </div>
              <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" id="ornumber" name="ornumber" required autofocus>
            </div>
            <div class="input-group input-group-sm mb-3">
              <div class="input-group-prepend">
                <span class="input-group-text" id="inputGroup-sizing-sm">Amount (Php):</span>
              </div>
              <input type="number" step="0.01" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" id="amount" name="amount" required>
            </div>
            <div class="input-group input-group-sm mb-3">
              <div class="input-group-prepend">
                <span class="input-group-text" id="inputGroup-sizing-sm">Payment Date:</span>
              </div>
              <input type="date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="paymentdate" required>
            </div>
            <div class="input-group input-group-sm mb-3">
              <div class="input-group-prepend">
                <span class="input-group-text" id="inputGroup-sizing-sm">Remarks:</span>
              </div>
              <input type="text" class="form-control" aria-label="Small" value="settle payment" aria-describedby="inputGroup-sizing-sm" name="remarks">
            </div>

          </div>
      </div>
      <div class="modal-footer">
        <button type="reset" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
        <button type="submit" onclick="form_submit()" class="btn btn-primary btn-sm">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!-- End Modal -->


                    <!-- ============================================================== -->
                    <!-- End PAge Content -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- Right sidebar -->
                    <!-- ============================================================== -->
                    <!-- .right-sidebar -->
                    <!-- ============================================================== -->
                    <!-- End Right sidebar -->
                    <!-- ============================================================== -->
                </div>
                <!-- ============================================================== -->
                <!-- End Container fluid  -->
                <!-- ============================================================== -->

<?php $__env->stopSection(); ?>
<script type="text/javascript">
function form_submit() {
  var orn = document.getElementById('ornumber').value;
  if(orn == null || orn == ""){
    alert('Pleaser enter OR Number');
  }else{
    var txt;
    var r = confirm("Please confirm your entries.");
    if (r == true) {
        document.getElementById("paymentForm").submit();
    } else {
        alert("You pressed Cancel!");
    }
  }

}
function addpayment(j,a)
{
  document.getElementById('joid').value = j.toString();
  document.getElementById('amount').value = a.toString();
  //alert(j+'   '+a);
}
</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\joTracking_v0.3\resources\views/billing/index.blade.php ENDPATH**/ ?>