<h1><?php echo e($title); ?></h1>
<p>This is my first Email using laravel 5.7</p><?php /**PATH D:\joTracking_v0.3\resources\views/emails/email.blade.php ENDPATH**/ ?>