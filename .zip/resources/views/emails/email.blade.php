<h1>{{ $title }}</h1>
<p>This is my first Email using laravel 5.7</p>