<?php $__env->startSection('content'); ?>
<div class="row bg-title">
    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
      <h4 class="page-title">Manage Tasks</h4> </div>
      <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
        <!-- <a href="https://wrappixel.com/templates/ampleadmin/" target="_blank" class="btn btn-danger pull-right m-l-20 hidden-xs hidden-sm waves-effect waves-light">Upgrade to Pro 2</a> -->       
        <ol class="breadcrumb">

            <li><a href="<?php echo e(url('home')); ?>">Dashboard</a></li>
            <li class="active">Manage Tasks</li>
        </ol>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<!-- ============================================================== -->
<!-- Different data widgets -->
<!-- ============================================================== -->
<!-- .row -->
<div class="row">

    <div class="col-lg-6 col-sm-6 col-xs-12">
        <div class="white-box analytics-info">
            <h3 class="box-title text-info"> DUE TODAY </h3>
            <table class="table table-sm table-hover">
                <thead>
                    <th>JO#</th>
                    <th>Client</th>
                    <th>Task Name</th>
                    <th>Date Due</th>
                    <th>State</th>
                </thead>
                <tbody>
                    <?php if(count($duetasks) > 0): ?>
                    <?php $__currentLoopData = $duetasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtask): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($dtask->joid); ?></td>
                        <td><?php echo e($dtask->clientname); ?></td>
                        <td><?php echo e($dtask->taskname); ?></td>
                        <td><?php echo e($dtask->datedue); ?></td>
                        <td><?php echo e($dtask->state); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="col-lg-6 col-sm-6 col-xs-12">
        <div class="white-box analytics-info">
            <h3 class="box-title text-danger"> PAST DUE </h3>
            <table class="table table-sm table-hover">
                        <thead>
                          <th>JO#</th>
                          <th>Client</th>
                          <th>Task Name</th>
                          <th>Date Due</th>
                          <th>State</th>
                        </thead>
                        <tbody>
                          <?php if(count($tasks) > 0): ?>
                          <?php $__currentLoopData = $pduetasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ptask): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($ptask->joid); ?></td>
                              <td><?php echo e($ptask->clientname); ?></td>
                              <td><?php echo e($ptask->taskname); ?></td>
                              <td><?php echo e($ptask->datedue); ?></td>
                              <td><?php echo e($ptask->state); ?></td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                        </tbody>
                    </table>
        </div>
    </div>
    <div class="col-lg-6 col-sm-6 col-xs-12">
        <div class="white-box analytics-info">
            <h3 class="box-title text-warning"> INCOMING DUE </h3>
            <table class="table table-sm table-hover">
                        <thead>
                          <th>JO#</th>
                          <th>Client</th>
                          <th>Task Name</th>
                          <th>Date Due</th>
                          <th>State</th>
                        </thead>
                        <tbody>
                          <?php if(count($intasks) > 0): ?>
                          <?php $__currentLoopData = $intasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itask): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($itask->joid); ?></td>
                              <td><?php echo e($itask->clientname); ?></td>
                              <td><?php echo e($itask->taskname); ?></td>
                              <td><?php echo e($itask->datedue); ?></td>
                              <td><?php echo e($itask->state); ?></td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                        </tbody>
                    </table>
        </div>
    </div>
    <div class="col-lg-6 col-sm-6 col-xs-12">
        <div class="white-box analytics-info">
            <h3 class="box-title text-success"> DONE </h3>
            <?php if(count($tasks) > 0): ?>
                    <table class="table table-sm table-hover">
                        <thead>
                          <th>JO#</th>
                          <th>Client</th>
                          <th>Task Name</th>
                          <th>Date Due</th>
                          <th>State</th>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($task->tsid <= 7): ?>
                            <tr>
                              <td><?php echo e($task->joid); ?></td>
                              <td><?php echo e($task->clientname); ?></td>
                              <td><?php echo e($task->taskname); ?></td>
                              <td><?php echo e($task->datedue); ?></td>
                              <td><?php echo e($task->state); ?></td>
                            </tr>
                          <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($tasks->links()); ?>

                    <?php endif; ?>
        </div>
    </div>

</div>
<!--/.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projmngt\resources\views/task/mytasks.blade.php ENDPATH**/ ?>