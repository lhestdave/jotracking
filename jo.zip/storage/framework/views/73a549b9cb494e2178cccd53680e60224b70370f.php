<?php $__env->startSection('content'); ?>
<div class="row bg-title">
    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
      <h4 class="page-title">Manage Clients</h4> </div>
      <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
        <!-- <a href="https://wrappixel.com/templates/ampleadmin/" target="_blank" class="btn btn-danger pull-right m-l-20 hidden-xs hidden-sm waves-effect waves-light">Upgrade to Pro 2</a> -->       
        <ol class="breadcrumb">

            <li> 

            <form class="form-inline my-2 my-lg-0" action="<?php echo e(url('clients/search')); ?>" method="post">
              <?php if(count($admin)>0): ?>
                  <button class="btn btn-outline-primary my-2 my-sm-0" data-toggle="modal" data-target="#newClientModal" type="button" onclick="addNew(1)">New Client</button> &nbsp
                  <?php endif; ?>
              <?php echo e(csrf_field()); ?>

              <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" name="csearchkey">
              <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
            </form>
            </li>

            <li><a href="<?php echo e(url('home')); ?>">Dashboard</a></li>
            <li class="active">Manage Clients</li>
        </ol>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<!-- ============================================================== -->
<!-- Different data widgets -->
<!-- ============================================================== -->
<!-- .row -->
<div class="row">
  <?php if(count($errors) > 0): ?>
    <div class="alert alert-danger alert-dismissible">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
      <strong>Error!</strong>
      <?php echo e($errors->first('clientname')); ?><br>
      <?php echo e($errors->first('contactno')); ?><br>
      <?php echo e($errors->first('cperson')); ?><br>
    </div>
    <?php endif; ?>
    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
      <strong>Success! </strong><?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>
  <div class="col-sm-12">
        <div class="white-box analytics-info">
            <h3 class="box-title">List of Clients</h3>

            <table class="table table-hover table-responsive">
                    <thead>
                      <tr>
                        <th scope="col">TIN</th>
                        <th scope="col">Company/Client</th>
                        <th scope="col">Branch</th>
                        <th scope="col">Contact No.</th>
                        <th scope="col">Contact Person</th>
                        <th scope="col">Email Address</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if(count($clients) > 0): ?>
                         <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr id="tr<?php echo e($client->id); ?>">
                            <td><?php echo e($client->tin); ?></td>
                             <td><?php echo e($client->clientname); ?></td>
                             <td><?php echo e($client->branch); ?></td>
                             <td><?php echo e($client->contactno); ?></td>
                             <td><?php echo e($client->cperson); ?></td>
                             <td><?php echo e($client->email); ?></td>
                             <td>
                               <?php if(count($admin)>0): ?>
                               <button class="btn btn-success" data-toggle="modal" rel="tooltip" title="Edit Client" data-target="#newClientModal"
                               onclick="updateClient('5','<?php echo e($client->id); ?>','<?php echo e($client->clientname); ?>','<?php echo e($client->branch); ?>','<?php echo e($client->busadd); ?>','<?php echo e($client->tin); ?>','<?php echo e($client->email); ?>','<?php echo e($client->contactno); ?>','<?php echo e($client->cperson); ?>')"
                               ><i class="fa fa-edit" aria-hidden="true"></i></button>
                               <?php endif; ?>
                               <a href="<?php echo e(url('jo/view/')); ?>/<?php echo e($client->id); ?>">
                               <button class="btn btn-success" data-toggle="modal" rel="tooltip" title="View JOs" ><i class="fa fa-bars"></i></button>
                              </a>
                              <a href="<?php echo e(url('jo/create?cid=')); ?><?php echo e($client->id); ?>">
                              <button class="btn btn-success" data-toggle="modal" rel="tooltip" title="Create JO" ><i class="fa fa-tasks"></i></button>
                             </a>
                             <a href="<?php echo e(url('billing/view')); ?>/<?php echo e($client->id); ?>">
                             <button class="btn btn-outline-success" data-toggle="modal" rel="tooltip" title="View Billing" ><i class="fa fa-money"></i></button>
                            </a>
                             </td>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php else: ?>
                     <tr>
                       <td colspan="9"><center>No Data Found.</center></td>
                     </tr>
                     <?php endif; ?>

                    </tbody>
                  </table>
                  <?php echo e($clients->links()); ?>



        </div>
    </div>
</div>
<!--/.row -->


<!-- Modal -->
<div class="modal fade" id="newClientModal" tabindex="-1" role="dialog" aria-labelledby="newClientModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Client</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form class="form-horizontal" id="clientForm" action="<?php echo e(url('/addnewclient')); ?>" method="post">
          <?php echo e(csrf_field()); ?>

          <input type="text" name="eventid" id="eventid" value="" hidden>
          <input type="text" name="cid" id="cid" value="" hidden>
            <div class="form-group">
              <label class="control-label col-sm-5" for="clientname" style="text-align:left;">Client Name:</label>
              <div class="col-sm-12">
                <input type="text" class="form-control" id="clientname" placeholder="Enter Company Name" name="clientname" value="<?php echo e(old('clientname')); ?>">
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-sm-2" for="branch" style="text-align:left;">Branch</label>
              <div class="col-sm-12">
                <input type="text" class="form-control" id="branch" placeholder="Enter Branch" name="branch" value="<?php echo e(old('branch')); ?>">
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-sm-2" for="busadd" style="text-align:left;">Address</label>
              <div class="col-sm-12">
                <input type="text" class="form-control" id="busadd" placeholder="Enter Business Address" name="busadd" value="<?php echo e(old('busadd')); ?>">
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-sm-2" for="tin" style="text-align:left;">Tax ID No.</label>
              <div class="col-sm-12">
                <input type="text" class="form-control" id="tin" placeholder="Enter TIN" name="tin" value="<?php echo e(old('tin')); ?>">
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-sm-12" for="contactno" style="text-align:left;">Contact No. (Tel/CP)</label>
              <div class="col-sm-12">
                <input type="text" class="form-control" id="contactno" placeholder="Enter Contact No." name="contactno" value="<?php echo e(old('contactno')); ?>">
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-sm-12" for="email" style="text-align:left;">Company Email:</label>
              <div class="col-sm-12">
                <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" value="<?php echo e(old('email')); ?>">
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-sm-8" for="cperson" style="text-align:left;">Contact Person</label>
              <div class="col-sm-12">
                <input type="text" class="form-control" id="cperson" placeholder="Enter Contact Person" name="cperson" value="<?php echo e(old('cperson')); ?>">
              </div>
            </div>
      </div>
      <div class="modal-footer">
        <button type="reset" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" onclick="form_submit()" class="btn btn-primary">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!-- End Modal -->
<?php $__env->stopSection(); ?>

<script type="text/javascript">
function form_submit()
{
  document.getElementById("clientForm").submit();
}
function addNew(eid)
{
  //1-new
  //5-update
  document.getElementById("clientForm").reset();
  document.getElementById("eventid").value = eid.toString();
}
function updateClient(code,id,client,branch,busadd,tin,email,con,cper)
{
  document.getElementById("eventid").value = code.toString();
  document.getElementById("cid").value = id.toString();
  document.getElementById("clientname").value = client.toString();
  document.getElementById("branch").value = branch.toString();
  document.getElementById("busadd").value = busadd.toString();
  document.getElementById("tin").value = tin.toString();
  document.getElementById("email").value = email.toString();
  document.getElementById("contactno").value = con.toString();
  document.getElementById("cperson").value = cper.toString();
}

</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projmngt\resources\views/client/index.blade.php ENDPATH**/ ?>