<?php $__env->startSection('content'); ?>
<div class="container">
  <?php if(session('error')): ?>
  <div class="alert alert-danger alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error! </strong> <?php echo e(session('error')); ?>

  </div>
  <?php endif; ?>
  <?php if(session('success')): ?>
  <div class="alert alert-success alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success! </strong><?php echo e(session('success')); ?>

  </div>
  <?php endif; ?>
  <div class="col-sm-12 col-md-12 border-secondary" style="padding: 2px 2px 2px 2px;">
      <div class="card border-secondary">
          <div class="card-header border-secondary">Change Password</div>
          <div class="card-body">
            <form class="" action="<?php echo e(url('/savechangepass')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <div class="form-group row">
                  <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Current Password')); ?></label>

                  <div class="col-md-6">
                      <input id="currentpassword" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="currentpassword" required autocomplete="new-password">

                      <?php if ($errors->has('currentpassword')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('currentpassword'); ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                          </span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>
              </div>
              <div class="form-group row">
                  <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                  <div class="col-md-6">
                      <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

                      <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                          </span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>
              </div>

              <div class="form-group row">
                  <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                  <div class="col-md-6">
                      <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                  </div>
              </div>

              <div class="form-group row mb-0">
                  <div class="col-md-6 offset-md-4">
                      <button type="submit" class="btn btn-primary">
                          <?php echo e(__('Save')); ?>

                      </button>
                  </div>
              </div>

            </form>

          </div>
      </div>
  </div>

</div>
<?php $__env->stopSection(); ?>
<script type="text/javascript">
   jQuery(document).ready(function() {

   });
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projmngt\resources\views/changepass.blade.php ENDPATH**/ ?>